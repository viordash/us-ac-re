﻿// (c) Copyright Michael Bernstein, 2009.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL.
// All other rights reserved.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("UIAComWrapperX")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("UIAComWrapperX")]
[assembly: AssemblyCopyright("Copyright ©  2018 Techno Scavenger")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("74f2db3d-156a-4160-a401-011f601e1b56")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.1.0.16")]
[assembly: AssemblyFileVersion("1.1.0.16")]

[assembly: InternalsVisibleTo("UIAComWrapperXTests, PublicKey=00240000048000009400000006020000002400005253413100040000010001002b12949bc42c9ceccdc8e98f99a849017c9f4ffd19d656191727a431f00bd283848493e5318e3dee94636edd27b08c59ee3d1d4e0948a197341eb3e238cc08660d23191faecf5dd9566e9c2b1ca4fd89ee04fb220ef096cc6b0f1f51a278cc37f9ffc0d89015032ef0ab6196c374b407e0e6ca4ece4b90e52bd636f22b9342ee")]