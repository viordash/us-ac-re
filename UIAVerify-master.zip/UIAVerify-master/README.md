UIAVerify
=========

[![Build status](https://ci.appveyor.com/api/projects/status/7uk635l597k41xi0?svg=true)](https://ci.appveyor.com/project/ivan-danilov/uiaverify)

Clone of https://uiautomationverify.codeplex.com/

Original version is included to the Windows SDK
