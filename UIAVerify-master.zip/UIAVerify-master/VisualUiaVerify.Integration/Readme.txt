﻿This assembly contains interfaces that must be implemented by the third-party projects
wishing to integrate well with UIA, thus it is very lightweight and separated from exe
assembly.